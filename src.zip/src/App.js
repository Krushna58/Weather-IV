import React, { useState } from "react";

import Navbar1 from "./Component/NavBar1";
import WeatherCurrent from "./Component/WeatherCurrent";
import WeatherForecast from "./Component/WeatherForecast ";
import WeatherHistory from "./Component/WeatherHistory";
import 'bootstrap/dist/css/bootstrap.min.css';
import HourlyForecast from "./Component/HourlyForecast ";
import LocationDetector from "./Component/LocationDetector";
import 'bootstrap-icons/font/bootstrap-icons.css';



// import 'bootstrap-icons/font/bootstrap-icons.css';

import LoginForm from "./Component/LoginForm";
import { Route, Routes } from "react-router-dom";


function App() {
  const [city, setCity] = useState(null);

  // const [user , serUser] = useState(null);    // for user login

 


  const handleSearch = (query) => {
    setCity(query);

    // console.log(city);
    
  };

  return (
    < >
        <Navbar1 onSearch={handleSearch} />

   {!city && <LocationDetector onLocationDetected={setCity}/>} 
    
   


      
      {/* <LoginForm/> */}
     
      
     
      {city ? (
        <>
        
      <WeatherCurrent city={city} />
      <HourlyForecast city={city}/>
       <WeatherForecast city={city} />
      
      
        </>
        
      ) : (
        <div className="text-center mt-5" >
           <h3>Detecting Location.....</h3> 
          <div className="spinner-border text-primary" role="status">
           
          </div>
        </div>
      )}

    
      
     

      
      {/* <WeatherHistory city={city}/>     // not in Requirement      */}
      
    </>
  );
}

export default App;