
import React, { useState } from 'react';
import { Form, Button, Container, Card, Alert } from 'react-bootstrap';
import axios from 'axios';

const LoginForm = () => {
  const [emailid, setEmailid] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [variant, setVariant] = useState('danger');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');

    try {
      const response = await axios.post('http://localhost:8080/Weather/api/user', {
        emailid,
        password,
      });

      setVariant('success');
      setMessage(`Welcome, ${response.data.name || 'User'}!`);
      console.log('Login success:', response.data);
    } catch (error) {
      setVariant('danger');
      if (error.response && error.response.status === 401) {
        setMessage('Invalid email or password.');
      } else {
        setMessage('Something went wrong. Please try again.');
      }
      console.error('Login error:', error);
    }
  };

  return (
    <Container className="d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
      <Card style={{ width: '24rem', padding: '20px' }}>
        <Card.Body>
          <Card.Title className="text-center mb-4">Login</Card.Title>
          {message && <Alert variant={variant}>{message}</Alert>}
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="formEmail">
              <Form.Label>Email ID</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter email"
                value={emailid}
                onChange={(e) => setEmailid(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group className="mb-4" controlId="formPassword">
              <Form.Label>Password</Form.Label>
              <Form.Control
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </Form.Group>

            <div className="d-grid">
              <Button variant="primary" type="submit">
                Login
              </Button>
            </div>
          </Form>
        </Card.Body>
      </Card>
    </Container>
  );
};

export default LoginForm;